#!/usr/bin/env python3
"""
历史科学类科普短视频素材生成脚本
自动生成3分钟科普视频的全流程素材：口播文案、分镜脚本、Veo2提示词、人物形象规范
"""

import os
import argparse
import sys
import json
from typing import Dict, List, Any
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_openai import ChatOpenAI
from coze_workload_identity import requests


# ==================== 配置常量 ====================
SKILL_ID = "7598365825573257262"
BASE_URL = os.getenv("COZE_LLM_BASE_URL", "")
API_KEY = os.getenv("COZE_LLM_API_KEY", "")

# ==================== 文案结构配置 ====================
SCRIPT_STRUCTURE = {
    "开篇悬念": {"duration": 20, "content": "用[年份]+[科学事件/人物困惑]开头，引发观众好奇"},
    "历史背景": {"duration": 30, "content": "交代时代、地点、学术或社会背景"},
    "人物描写": {"duration": 25, "content": "突出科学家的特质（坚持、偏执、热情、天才）"},
    "事件与实验细节": {"duration": 45, "content": "数字化描写实验对象、方法、数量、时间、空间"},
    "发现与突破": {"duration": 35, "content": "明确科学结论或规律，用生动语言强调其重要性"},
    "意义与影响": {"duration": 30, "content": "解释科学发现如何改变学界、社会或文化"},
    "结尾反思": {"duration": 15, "content": "提出深思或未来探索问题"}
}

TOTAL_DURATION = sum(sec["duration"] for sec in SCRIPT_STRUCTURE.values())  # 200秒 = 3分20秒
TARGET_WORD_COUNT = 900  # 3分钟约900字


# ==================== 复古风格配置 ====================
RETRO_STYLE = """
复古照片风格要求：
- 色调：棕褐色调，色彩沉稳偏棕色
- 质感：轻微褪色，胶片颗粒感，档案感
- 光影：柔和阴影，历史真实感
- 注意事项：严格禁止出现不属于本年代之外的场景或物品
"""


# ==================== Veo2 提示词模板 ====================
VEO2_PROMPT_TEMPLATE = """
主体（Subject）：
- 视频的主要对象是什么
- 对象的特征和细节
- 对象的数量（如果是多个）

动作（Action）：
- 场景中发生什么动作
- 动作的速度和节奏
- 动作的连续性

场景（Setting）：
- 环境描述
- 背景元素
- 空间感

镜头角度（Camera Angle/Movement）：
- 镜头类型（特写、远景等）
- 镜头运动（平移、推进等）
- 视角变化

灯光（Lighting）：
- 光源类型
- 光线强度
- 光影效果

风格/情绪（Style/Mood）：
- 视觉风格：棕褐色调，复古历史照片质感，轻微褪色效果，细腻胶片颗粒感，柔和阴影
- 情感氛围：根据文案情绪调整（悬念/严肃/激昂/沉静）
- 艺术效果：历史真实感与档案感拉满，无任何跨年代元素
"""


# ==================== 大模型调用 ====================
async def call_llm(prompt: str, temperature: float = 0.7) -> str:
    """调用大模型生成内容"""
    if not BASE_URL or not API_KEY:
        raise ValueError("缺少大模型凭证配置，请设置环境变量 COZE_LLM_BASE_URL 和 COZE_LLM_API_KEY")
    
    llm = ChatOpenAI(
        model="doubao-seed-1-6-251015",
        api_key=API_KEY,
        base_url=BASE_URL,
        streaming=False,
        temperature=temperature,
        max_tokens=4000,
        extra_body={"thinking": {"type": "disabled"}}
    )
    
    messages = [
        SystemMessage(content="""你是一位专业的科普短视频制作专家，擅长创作历史科学类视频素材。
你的任务是根据用户提供的主题、年代和核心结论，生成高质量的科普文案、分镜脚本和视觉提示词。

输出要求：
1. 文案：语言口语化、生活化，但保留科学准确性；多用数字、年份、数量增强真实感；短句与长句交替，增强节奏感
2. 分镜：每镜对应1-2句文案，时长4-6秒；保持复古照片风格；画面连续性和衔接性
3. 提示词：使用Veo2标准格式，涵盖主体、动作、场景、镜头角度、灯光、风格/情绪
4. 人物：保持人物一致性，服饰和道具严格贴合对应年代

请严格按照要求的格式输出，不要添加额外的说明文字。"""),
        HumanMessage(content=prompt)
    ]
    
    try:
        response = await llm.ainvoke(messages)
        return response.content
    except Exception as e:
        raise Exception(f"大模型调用失败: {str(e)}")


# ==================== 文案生成 ====================
async def generate_script(theme: str, era: str, core_conclusion: str) -> str:
    """生成3分钟口播文案"""
    prompt = f"""请根据以下信息生成一个3分钟的历史科学类科普短视频口播文案：

【主题】：{theme}
【年代背景】：{era}
【核心科学结论】：{core_conclusion}

【文案结构要求】（严格按顺序，总时长约3分钟）：
1. 开篇悬念（20秒）：用 [年份]+[科学事件/人物困惑] 开头，引发观众好奇
2. 历史背景（30秒）：交代时代、地点、学术或社会背景
3. 人物描写（25秒）：突出科学家的特质（坚持、偏执、热情、天才）
4. 事件与实验细节（45秒）：数字化描写实验对象、方法、数量、时间、空间
5. 发现与突破（35秒）：明确科学结论或规律，用生动语言强调其重要性
6. 意义与影响（30秒）：解释科学发现如何改变学界、社会或文化
7. 结尾反思（15秒）：提出深思或未来探索问题

【语言特点】：
- 使用短句与长句交替，增强节奏感
- 口语化、生活化，但保留科学准确性
- 多用数字、年份、数量增强真实感
- 适当加入比喻或类比，让抽象概念易理解

【输出格式】：
请直接输出文案内容，每个部分用【部分名称】标注，不要添加其他说明。

示例格式：
【开篇悬念】
1961年冬天，麻省理工学院的一间实验室里...

【历史背景】
20世纪60年代的美国，正值计算机科学蓬勃发展的时期...

请开始生成："""

    return await call_llm(prompt, temperature=0.8)


# ==================== 人物形象生成 ====================
async def generate_character_design(script: str, era: str) -> str:
    """生成人物形象规范"""
    prompt = f"""请根据以下文案和年代背景，生成统一、贴合时代的人物形象规范：

【口播文案片段】：
{script[:1000]}

【年代背景】：{era}

【人物形象要求】：
1. 设计一个或多个符合时代背景的人物形象（科学家、实验者等）
2. 外貌细节：年龄、发型、面部特征、神态
3. 服饰：符合对应年代的服装、配饰
4. 动作特征：与实验或研究相关的动作
5. 道具：实验器械、工具等
6. 复古风格：棕褐色调，胶片颗粒感，柔和侧光

【输出格式】：
请按以下格式输出人物形象规范：

【人物1：姓名】
年龄：XX岁
性别：XX
发型：描述
面部特征：描述
服饰：详细描述（年代、材质、颜色）
神态：描述
动作特征：描述
道具：描述
特写提示词：详细的视觉描述，用于生成人物特写图片

请开始生成："""

    return await call_llm(prompt, temperature=0.7)


# ==================== 分镜脚本生成 ====================
async def generate_storyboard(script: str, character_design: str) -> str:
    """生成分镜脚本"""
    prompt = f"""请根据以下文案和人物形象规范，生成详细的分镜脚本：

【口播文案】：
{script}

【人物形象规范】：
{character_design[:1500]}

【分镜要求】：
1. 总时长：3分钟（约180秒）
2. 分镜数量：30-35个分镜
3. 单镜时长：4-6秒
4. 镜头类型：远景、中景、近景、特写合理搭配
5. 镜头运动：平移、推进、拉远等自然衔接
6. 画面连续性：保证画面的连续性和衔接性
7. 空镜：适当加入空镜（实验场景、历史环境等）

【复古风格】：
- 棕褐色调
- 轻微褪色
- 胶片颗粒感
- 柔和阴影
- 严格禁止出现不属于本年代之外的场景或物品

【输出格式】：
请按以下格式生成分镜脚本：

镜头1：【镜头类型】（XX秒）
画面内容：详细描述
人物动作：如有
镜头运动：描述

镜头2：【镜头类型】（XX秒）
...

请开始生成分镜脚本："""

    return await call_llm(prompt, temperature=0.7)


# ==================== Veo2 提示词生成 ====================
async def generate_veo2_prompts(storyboard: str, era: str) -> str:
    """生成Veo2提示词清单"""
    prompt = f"""请根据以下分镜脚本和年代背景，生成符合Veo2标准的详细提示词：

【分镜脚本】：
{storyboard}

【年代背景】：{era}

【Veo2提示词标准格式】：
主体（Subject）：
- 视频的主要对象是什么
- 对象的特征和细节
- 对象的数量（如果是多个）

动作（Action）：
- 场景中发生什么动作
- 动作的速度和节奏
- 动作的连续性

场景（Setting）：
- 环境描述
- 背景元素
- 空间感

镜头角度（Camera Angle/Movement）：
- 镜头类型（特写、远景等）
- 镜头运动（平移、推进等）
- 视角变化

灯光（Lighting）：
- 光源类型
- 光线强度
- 光影效果

风格/情绪（Style/Mood）：
- 视觉风格：棕褐色调，复古历史照片质感，轻微褪色效果，细腻胶片颗粒感，柔和阴影
- 情感氛围：根据文案情绪调整（悬念/严肃/激昂/沉静）
- 艺术效果：历史真实感与档案感拉满，无任何跨年代元素

【输出要求】：
- 为每个分镜生成一条完整的Veo2提示词
- 使用清晰、具体的描述
- 包含所有必要的视觉元素
- 保持逻辑性和连贯性
- 避免模糊或矛盾的描述

【输出格式】：
镜头1提示词：
主体：...
动作：...
场景：...
镜头角度：...
灯光：...
风格/情绪：...

镜头2提示词：
...

请开始生成Veo2提示词清单："""

    return await call_llm(prompt, temperature=0.6)


# ==================== 主流程 ====================
async def main():
    """主函数：生成全流程素材"""
    parser = argparse.ArgumentParser(description="历史科学类科普短视频素材生成")
    parser.add_argument("--theme", required=True, help="科普主题（如：蝴蝶效应的起源）")
    parser.add_argument("--era", required=True, help="年代背景（如：1961年）")
    parser.add_argument("--core_conclusion", required=True, help="核心科学结论")
    parser.add_argument("--output_dir", default="./output", help="输出目录（默认：./output）")
    
    args = parser.parse_args()
    
    # 创建输出目录
    os.makedirs(args.output_dir, exist_ok=True)
    
    print(f"🎬 开始生成历史科学类科普短视频素材")
    print(f"📌 主题：{args.theme}")
    print(f"📅 年代：{args.era}")
    print(f"💡 核心结论：{args.core_conclusion}")
    print(f"📂 输出目录：{args.output_dir}")
    print()
    
    try:
        # 1. 生成文案
        print("📝 [1/4] 生成3分钟口播文案...")
        script = await generate_script(args.theme, args.era, args.core_conclusion)
        script_path = os.path.join(args.output_dir, "script.txt")
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(script)
        print(f"   ✅ 文案已生成：{script_path}")
        
        # 2. 生成人物形象
        print("👤 [2/4] 生成人物形象规范...")
        character_design = await generate_character_design(script, args.era)
        character_path = os.path.join(args.output_dir, "character_design.md")
        with open(character_path, "w", encoding="utf-8") as f:
            f.write(character_design)
        print(f"   ✅ 人物形象已生成：{character_path}")
        
        # 3. 生成分镜脚本
        print("🎬 [3/4] 生成分镜脚本...")
        storyboard = await generate_storyboard(script, character_design)
        storyboard_path = os.path.join(args.output_dir, "storyboard.md")
        with open(storyboard_path, "w", encoding="utf-8") as f:
            f.write(storyboard)
        print(f"   ✅ 分镜脚本已生成：{storyboard_path}")
        
        # 4. 生成Veo2提示词
        print("🎨 [4/4] 生成Veo2提示词清单...")
        veo2_prompts = await generate_veo2_prompts(storyboard, args.era)
        prompts_path = os.path.join(args.output_dir, "veo2_prompts.txt")
        with open(prompts_path, "w", encoding="utf-8") as f:
            f.write(veo2_prompts)
        print(f"   ✅ Veo2提示词已生成：{prompts_path}")
        
        print()
        print("🎉 所有素材生成完成！")
        print(f"📦 素材包位置：{args.output_dir}/")
        print("   - script.txt           （3分钟口播文案）")
        print("   - storyboard.md        （分镜脚本表）")
        print("   - veo2_prompts.txt     （Veo2提示词清单）")
        print("   - character_design.md  （人物形象规范）")
        print()
        print("💡 下一步：使用 Veo2 提示词在即梦平台生成视频素材")
        
    except Exception as e:
        print(f"\n❌ 生成失败：{str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
